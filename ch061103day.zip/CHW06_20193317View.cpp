﻿


#include "pch.h"
#include "framework.h"

#ifndef SHARED_HANDLERS
#include "CHW06_20193317.h"
#endif

#include "CHW06_20193317Doc.h"
#include "CHW06_20193317View.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif




IMPLEMENT_DYNCREATE(CCHW0620193317View, CView)

BEGIN_MESSAGE_MAP(CCHW0620193317View, CView)
	
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CView::OnFilePrintPreview)
	ON_WM_CHAR()
	ON_WM_RBUTTONDOWN()
	ON_WM_LBUTTONDOWN()
END_MESSAGE_MAP()



CCHW0620193317View::CCHW0620193317View() noexcept
{
	

}

CCHW0620193317View::~CCHW0620193317View()
{
}




void CCHW0620193317View::OnDraw(CDC* pDC)
{
	CCHW0620193317Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;


	//CRect rectCnt;
	//AfxGetMainWnd()->GetClientRect(&rectCnt);
	//GetClientRect(&rectCnt);

	//srand((int)time(NULL));
	

	pDC->SetBkColor(RGB(255, 255, 0)); // 배경을 노란색으로 설정
	CBrush	brush(RGB(255, 255, 0));
	pDC->SelectObject(&brush);
	
	CString strNum;
	int i;
	for (i = 0; i < 10; i++)
	{
		if (pDoc->m_bNums[i])
		{
			strNum.Format(_T("%d"), i + 1);
			pDC->Ellipse(&(pDoc->m_rects[i]));
			pDC->DrawText(strNum, &(pDoc->m_rects[i]), DT_CENTER | DT_VCENTER | DT_SINGLELINE);
		}
	}
}



BOOL CCHW0620193317View::OnPreparePrinting(CPrintInfo* pInfo)
{
	// 기본적인 준비
	return DoPreparePrinting(pInfo);
}

void CCHW0620193317View::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	
}

void CCHW0620193317View::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	
}




#ifdef _DEBUG
void CCHW0620193317View::AssertValid() const
{
	CView::AssertValid();
}

void CCHW0620193317View::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CCHW0620193317Doc* CCHW0620193317View::GetDocument() const // 디버그되지 않은 버전은 인라인으로 지정됩니다.
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CCHW0620193317Doc)));
	return (CCHW0620193317Doc*)m_pDocument;
}
#endif //_DEBUG





void CCHW0620193317View::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	CCHW0620193317Doc* pDoc = GetDocument();

	// [Backspace] 입력 시 맨 마지막 글자를 삭제한다.
	if (nChar == _T('\b')) {
		if (pDoc->m_str.GetSize() > 0)
			pDoc->m_str.RemoveAt(pDoc->m_str.GetSize() - 1);
	}
	// 그 밖의 경우에는 동적 배열에 글자를 추가한다.
	else {
		pDoc->m_str.Add(nChar);
	}

	// 데이터가 수정되었음을 도큐먼트 객체에 알린다.
	pDoc->SetModifiedFlag();

	// 뷰의 화면을 갱신한다.
	Invalidate();
}

void CCHW0620193317View::OnRButtonDown(UINT nFlags, CPoint point)
{
	CCHW0620193317Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	CRect rectCnt;
	GetClientRect(&rectCnt);

	srand((int)time(NULL));

	int i, x, y;
	for (i = 0; i < 10; i++)
	{
		x = rand() % rectCnt.right;
		y = rand() % rectCnt.bottom;
		pDoc->m_rects[i] = CRect(x - 20, y - 20, x + 20, y + 20);

		pDoc->m_bNums[i] = TRUE;
	}

	Invalidate();

}


void CCHW0620193317View::OnLButtonDown(UINT nFlags, CPoint point)
{
	CCHW0620193317Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	int i;
	for (i = 0; i < 10; i++)
	{
		CRgn rgn;
		rgn.CreateEllipticRgnIndirect(&(pDoc->m_rects[i]));
		if (rgn.PtInRegion(point))
		{
			pDoc->m_bNums[i] = FALSE;
			Invalidate();
			break;
		}
	}

}